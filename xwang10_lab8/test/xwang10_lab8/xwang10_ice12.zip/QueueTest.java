package xwang10_lab8;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QueueTest {

    @Test
    void enqueue() {
        Queue<Double> queueDouble = new Queue<>();
        queueDouble.enqueue(1.2);
        assertEquals(1.2, queueDouble.peek());
    }

    @Test
    void empty() {
        Queue<Double> queueDouble = new Queue<>();
        boolean isEmpty = queueDouble.empty();
        assertEquals(isEmpty, true);
    }

    @Test
    void dequeue() {
        Queue<Double> queueDouble = new Queue<>();
        queueDouble.enqueue(1.4);
        queueDouble.enqueue(1.5);
        queueDouble.dequeue();
        assertEquals(1.5, queueDouble.peek());

    }

    @Test
    void peek() {
        Queue<Double> queueDouble = new Queue<>();
        queueDouble.enqueue(1.6);
        assertEquals(1.6, queueDouble.peek());
    }

    @Test
    void testToString() {
        Queue<Double> queueDouble = new Queue<>();
        queueDouble.enqueue(1.8);
        assertEquals("1", "1", queueDouble.toString());
    }
}