package xwang10_lab8;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StackTest {

    @Test
    void empty() {
        Stack<Double> stack = new Stack<>();
        boolean isEmpty = stack.empty();
        assertEquals(true, isEmpty);
    }

    @Test
    void push() {
        Stack<Double> stack = new Stack<>();
        stack.push(1.0);
        assertEquals(1.0, stack.peek());
    }

    @Test
    void pop() {
        Stack<Double> stack = new Stack<>();
        stack.push(1.0);
        stack.push(2.0);
        stack.pop();
        assertEquals(1.0, stack.peek());
    }

    @Test
    void peek() {
        Stack<Double> stack = new Stack<>();
        stack.push(3.0);
        assertEquals(3.0, stack.peek());
    }

    @Test
    void testToString() {
        Stack<Double> stack = new Stack<>();
        stack.push(4.0);
        assertEquals("1", "1", stack.toString());
    }
}