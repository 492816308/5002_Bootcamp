/*
 * Xiaoyu Wang
 * CPSC 5001, Seattle University
 * This is free and unencumbered software released into the public domain.
 */
package SU_xwang10_ice12;

/**
 * This is a sample program that will print "Hello, World!" to screen.
 *
 * @author  Xiaoyu Wang
 * @version 1.0
 */
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}