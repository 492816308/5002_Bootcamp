/**
 * The LinkedList class implements a linked list.
 */
public class LinkedList {
    /**
     * The Node class represents a list node
     * and a reference to the next node.
     */
    private class Node {
        int value;
        Node next;

        /**
         * Constructor.
         *
         * @param val The element to store in this node.
         * @param n   The reference to the next node.
         */
        Node(int val, Node n) {
            value = val;
            next = n;
        }

        /**
         * Constructor.
         *
         * @param val The element to store in this node.
         */
        Node(int val) {
            value = val;
            next = null;
        }
    }

    // Reference to the first node in the list
    private Node head;

    /**
     * Constructor
     * Build a linkedlist.
     */
    public LinkedList() {
        head = null;
    }

    /**
     * The insertInOrder method append the number in ascending order.
     * @param val The number the be inserted.
     */
    public void insertInOrder(int val) {
        // Create a newNode object
        Node newNode = new Node(val);
        // Create a current Node to keep track of the number right after
        // starting from head
        Node current = head;
        // current value is greater than the inserted value
        while (current != null && current.value < val) {
            current = current.next;
        }
        // To check if the current node is the first node
        if (current == head) {
            newNode.next = head;
            head = newNode;
            return;
        }
        // Create a prev node to keep track of the node right before the inserted node
        Node prev = head;
        // Loop until it reaches the one before the current node
        while (prev != null && prev.next != current) {
            prev = prev.next;
        }
        // Connect the newNode pointer to the current Node
        newNode.next = current;
        // Connect the prev pointer to the newNode
        prev.next = newNode;
    }

    /**
     * The toString method computes the string representation of the list.
     * @return The string form of the list.
     */
    public String toString() {
        StringBuilder strBuilder = new StringBuilder();
        Node p = head;
        while (p != null) {
            strBuilder.append(p.value + "\n");
            p = p.next;
        }
        return strBuilder.toString();
    }

    /**
     * The print method prints out the sorted linked list.
     */
    public void print() {
        Node ref = head;
        while (ref != null) {
            System.out.println(ref.value);
            ref = ref.next;
        }
    }
}
